module.exports = {
    'database': 'mongodb://admin:passw3rd@ds125469.mlab.com:25469/positivitygame',
    'saltRounds': 10,
    'serverPort': 8080
};